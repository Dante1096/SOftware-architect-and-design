from django.contrib import admin
from django.urls import path
from helloworld.views import hello_world_html, hello_world_json

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', hello_world_html),  # Root URL mapped to HTML view
    path('hello/', hello_world_html, name='hello_world_html'),  # HTML view
    path('hello/json/', hello_world_json, name='hello_world_json'),  # JSON view
]
