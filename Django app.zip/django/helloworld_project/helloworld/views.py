from django.shortcuts import render
from django.http import JsonResponse

def hello_world_html(request):
    return render(request, 'index.html')

def hello_world_json(request):
    response_data = {'Message': 'Hello World!'}
    return JsonResponse(response_data)

