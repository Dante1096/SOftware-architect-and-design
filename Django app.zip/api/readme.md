

Greeter API System
This project contains the specification for a simple Greeter API system, which allows users to create greetings and retrieve them.

How to Run
To use the Greeter API, follow these steps:

Clone the repository to your local machine.
Navigate to the directory containing the YAML specification file (greeter-api.yaml).
Use a tool like Swagger Editor to view and interact with the API documentation. You can either:
Copy and paste the content of greeter-api.yaml into the Swagger Editor.
Import the greeter-api.yaml file directly into the Swagger Editor.
Once the API documentation is loaded in Swagger Editor, you can test the endpoints by sending requests.
Endpoints
POST /greetings: Creates a new greeting.
GET /greetings: Retrieves all greetings. Supports an optional limit query parameter to specify the maximum number of greetings to return.
Responses
200: Success response for both POST and GET endpoints.
500: Server error response for the POST endpoint, indicating issues such as server being too busy or greeting already exists.
Schema
The API uses the following schema:

Greeting: Represents a greeting object with an id (integer) and message (string).
Error: Represents an error object with code (integer) and message (string) fields.
Example Usage
Here's an example of how to create a greeting using cURL:

bash
Copy code
curl -X POST "http://example.com/greetings" -H "Content-Type: application/json" -d '{